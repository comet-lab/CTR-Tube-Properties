# secondary_repos_to_clone.csv

Clone secondary repositories based on information specified in the csv (comma-separated values) file.

A csv file is used so both the developer's clone script and Bamboo can get cloning information from 
the same location.  Note that the main (aka "default") source repo needs to be manually cloned since 
that's what Bamboo does.  It likely has to be already cloned so you have access to these Spec files.  
Do not include the main repo in the CSV file.

CSV Format:  
`clone-URL, branch/tag-to-checkout, project-relative-local-path-to-clone-to, special-clone-options`*

  *The special options are ignored by Bamboo
  
  Examples
  
      ssh://git@bitbucket.ndigital.com:7999/ext/catch.git, v2.1.0, open_source/catch, --depth 1
      ssh://git@bitbucket.ndigital.com:7999/ndi/ble_easy.git, master, common/ble_easy, 

Notes:
- Blank fields are represented by a comma and space (i.e. no special-clone-options would be ", ")
- Don't put empty lines in the csv file (the script that reads it is pretty dumb).
- Use the # symbol at the beginning of a line to add comments
- File must use Unix-style line endings!  (line-feeds, not carriage-return + line-feeds).
- For this to work in Bamboo, you must use Bamboo Specs to create/manage your Plan.  See [Bamboo Specs](https://confluence.ndigital.com:9443/x/-IbcAg) in Confluence for details.