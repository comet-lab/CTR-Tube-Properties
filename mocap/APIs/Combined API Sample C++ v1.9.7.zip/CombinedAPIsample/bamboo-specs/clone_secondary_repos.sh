#!/bin/bash

# Clone secondary repositories based on information specified in a csv (comma-separated values) file
# IMPORTANT: This is only for "secondary" repos.  The main repo has to be manually cloned first to
# match what Bamboo does (and likely to get this file so you can clone the other repos).
# 
# A csv file is used so both the developer's clone script and Bamboo can get cloning 
# information from the same location.
#
# CSV Format:  clone-URL, branch/tag-to-checkout, project-relative-local-path-to-clone-to, special-clone-options*
#   *The special options are ignored by Bamboo
#   Examples
#       ssh://git@bitbucket.ndigital.com:7999/ext/catch.git, v2.1.0, open_source/catch, --depth 1
#       ssh://git@bitbucket.ndigital.com:7999/ndi/ble_easy.git, master, common/ble_easy, 
#
# Notes:
# - Blank fields are represented by a comma and space (i.e. no special-clone-options would be ", ")
# - Use the # symbol at the beginning of a line to add comments
# - Don't put any empty lines in the csv file.
# - File must use Unix-style line endings!  (line-feeds, not carriage-return + line-feeds).
# - You must have SSH keys already setup on your computer (i.e. in ~/.ssh).
# - Be careful to not add functionality to this script that would make it diverge from Bamboo's build.

# Path to repo-information csv file, relative to project root (up one level from here)
inputFile="secondary_repos_to_clone.csv"

# Check that the csv file exists
if ! test -f "$inputFile"; then
    echo "$inputFile doesn't exists.  Nothing to clone."
    exit 0
fi

# Check that the file contains enough characters to be an entry (use 7 even though you'd need more)
inputFileSize=$(stat --format=%s "$inputFile")
echo "$inputFileSize"
if (( $inputFileSize < 7 )); then
    echo "$inputFile doesn't contain enough data.  Nothing to clone."
    exit 0
fi

# Clone from the root of the project
# TODO:  Modify the "cd" command below to go up to the project root.  In most cases this is "cd .."
# but if you cloned the repo further down (e.g. fw/polaris), you'll need to go up higher (cd ../..).
cd ..

# IFS is the internal field separator.  In this case, a comma.
# -r forces '\' in the strings to be used litterally and not as escape characters.
# < $inputFile reads input from a file rather than from standard-in.
while IFS=, read -r url label localPath options
do
	firstChar=${url:0:1}
	# Check for comments in the .csv file
	if [[ $firstChar != \# ]]; then
		git clone -b $label $options $url $localPath;
	fi
done < $inputFile
