package ndi_bamboo_specs;

import com.atlassian.bamboo.specs.api.builders.plan.Plan;
import com.atlassian.bamboo.specs.api.util.EntityPropertiesBuilders;
import org.junit.Test;

public class CAPIPlanSpecTest {
    @Test
    public void checkYourPlanOffline() {
        final CAPIPlanSpec planSpec = new CAPIPlanSpec();
        final Plan plan = planSpec.plan();

        EntityPropertiesBuilders.build(plan);
    }
}
