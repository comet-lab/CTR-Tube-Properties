/*
 * Copyright 2022 by Northern Digital Inc.
 * All Rights Reserved
 */
package ndi_bamboo_specs.wrappers;

import com.atlassian.bamboo.specs.api.builders.plan.artifact.Artifact;

/**
 * Convenience class providing a compact syntax for declaring a build artifact.
 *
 */
public class NdiArtifact extends Artifact
{
    public NdiArtifact(String name, String pattern, String path)
    {
        this.name( name ).copyPattern( pattern ).location( path );
    }
    
    public NdiArtifact(String name, String pattern)
    {
        this.name( name ).copyPattern( pattern );
    }
}
