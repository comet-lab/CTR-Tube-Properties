/*
 * Copyright 2022 by Northern Digital Inc.
 * All Rights Reserved
 */
package ndi_bamboo_specs.wrappers;

import com.atlassian.bamboo.specs.builders.task.CheckoutItem;
import com.atlassian.bamboo.specs.builders.task.VcsCheckoutTask;

/**
 * Convenience class providing a compact syntax for specifying source checkouts.
 *
 */
public class NdiCheckoutTask extends VcsCheckoutTask
{
    public NdiCheckoutTask( String description, boolean isClean )
    {
        this.cleanCheckout( isClean );
    }

    @Override
    public NdiCheckoutTask addCheckoutOfRepository( String repoName )
    {
        super.addCheckoutOfRepository( repoName );
        
        return this;
    }

    public NdiCheckoutTask addCheckoutOfRepository( String repoName, String checkoutPath )
    {
        this.checkoutItems( new CheckoutItem().repository( repoName ).path( checkoutPath ) );
        
        return this;
    }
}
