/*
 * Copyright 2022 by Northern Digital Inc.
 * All Rights Reserved
 */
package ndi_bamboo_specs.wrappers;

import com.atlassian.bamboo.specs.builders.task.ScriptTask;
import com.atlassian.bamboo.specs.model.task.ScriptTaskProperties.Interpreter;

/**
 * Convenience class providing a compact syntax for running build scripts.
 *
 */
public class NdiScriptTask extends ScriptTask
{
    public NdiScriptTask( String description, Interpreter interpreter )
    {
        this.description( description ).interpreter( interpreter );
    }

    public NdiScriptTask( String description, Interpreter interpreter, String workingPath )
    {
        this( description, interpreter );
        
        this.workingSubdirectory( workingPath );
    }
}
