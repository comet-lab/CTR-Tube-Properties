/*
 * Copyright 2022 by Northern Digital Inc.
 * All Rights Reserved
 */
package ndi_bamboo_specs;

public class RepoInfoEntry
{
    public final String url;
    public final String label;
    public final String localPath;
    public final String options;
    public final String name;
    public final String linkedRepoName;
    
    public RepoInfoEntry()
    {
        url = "";
        label = "";
        localPath = "";
        options = "";
        name = "";
        linkedRepoName = "";
    }
    
    public RepoInfoEntry(String p_url, String p_label, String p_localPath, String p_options, String p_name, String p_linkedRepoName)
    {
        url = p_url;
        label = p_label;
        localPath = p_localPath;
        options = p_options;
        name = p_name;
        linkedRepoName = p_linkedRepoName;
    }
}
