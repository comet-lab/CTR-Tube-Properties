/*
 * Copyright 2022 by Northern Digital Inc.
 * All Rights Reserved
 */
package ndi_bamboo_specs.wrappers;

import com.atlassian.bamboo.specs.builders.task.ScriptTask;

/**
 * Convenience class providing a compact syntax for creating echo tasks/log lines.
 *
 */
public class NdiEchoTask extends ScriptTask
{
    public NdiEchoTask( String description, String text )
    {
        this.description( description ).inlineBody( "echo " + text );
    }
}
