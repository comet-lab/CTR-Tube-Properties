/*
 * Copyright 2023 by Northern Digital Inc.
 * All Rights Reserved
 */

package ndi_bamboo_specs;

import com.atlassian.bamboo.specs.api.BambooSpec;
import com.atlassian.bamboo.specs.api.builders.AtlassianModule;
import com.atlassian.bamboo.specs.api.builders.BambooKey;
import com.atlassian.bamboo.specs.api.builders.Variable;
import com.atlassian.bamboo.specs.api.builders.notification.AnyNotificationRecipient;
import com.atlassian.bamboo.specs.api.builders.notification.Notification;
import com.atlassian.bamboo.specs.api.builders.permission.PermissionType;
import com.atlassian.bamboo.specs.api.builders.permission.Permissions;
import com.atlassian.bamboo.specs.api.builders.permission.PlanPermissions;
import com.atlassian.bamboo.specs.api.builders.plan.Job;
import com.atlassian.bamboo.specs.api.builders.plan.Plan;
import com.atlassian.bamboo.specs.api.builders.plan.PlanBranchIdentifier;
import com.atlassian.bamboo.specs.api.builders.plan.PlanIdentifier;
import com.atlassian.bamboo.specs.api.builders.plan.Stage;
import com.atlassian.bamboo.specs.api.builders.plan.artifact.Artifact;
import com.atlassian.bamboo.specs.api.builders.plan.branches.BranchCleanup;
import com.atlassian.bamboo.specs.api.builders.plan.branches.BranchIntegration;
import com.atlassian.bamboo.specs.api.builders.plan.branches.PlanBranchManagement;
import com.atlassian.bamboo.specs.api.builders.plan.configuration.ConcurrentBuilds;
import com.atlassian.bamboo.specs.api.builders.project.Project;
import com.atlassian.bamboo.specs.api.builders.repository.VcsRepositoryBranch;
import com.atlassian.bamboo.specs.api.builders.requirement.Requirement.MatchType;
import com.atlassian.bamboo.specs.builders.notification.CommittersRecipient;
import com.atlassian.bamboo.specs.builders.notification.PlanCompletedNotification;
import com.atlassian.bamboo.specs.builders.notification.PlanFailedNotification;
import com.atlassian.bamboo.specs.builders.notification.WatchersRecipient;
import com.atlassian.bamboo.specs.builders.task.ArtifactDownloaderTask;
import com.atlassian.bamboo.specs.builders.task.DownloadItem;
import com.atlassian.bamboo.specs.builders.trigger.BitbucketServerTrigger;
import com.atlassian.bamboo.specs.model.task.ScriptTaskProperties.Interpreter;
import com.atlassian.bamboo.specs.util.BambooServer;

import ndi_bamboo_specs.wrappers.NdiArtifact;
import ndi_bamboo_specs.wrappers.NdiCheckoutTask;
import ndi_bamboo_specs.wrappers.NdiRequirement;
import ndi_bamboo_specs.wrappers.NdiScriptTask;

/**
 * Plan configuration for Bamboo.
 * @see <a href="https://confluence.ndigital.com:9443/display/BAMBOO/Bamboo">NDI Bamboo Confluence Space</a>
 *
 * You can also consult the official Atlassian documentation.
 * @see <a href="https://confluence.atlassian.com/display/BAMBOO/Bamboo+Specs">Bamboo Specs</a>
 * @see <a href="https://docs.atlassian.com/bamboo-specs-docs/7.0.6/specs.html?java">Bamboo Specs Intro (v7.0.6)</a>
 * @see <a href="https://docs.atlassian.com/bamboo-specs/7.0.6/">Bamboo Specs API (v7.0.6)</a>
 */
@BambooSpec
public class CAPIPlanSpec
{
    // Start by reading in the file that contains all of the information about the secondary repos
    // that this plan depends on (repos that are needed in addition to the primary/default repo).
    RepoInfo secondaryRepoInfo = new RepoInfo("secondary_repos_to_clone.csv");
    
    private static final Artifact[] LINUX_ARTIFACTS = new Artifact[]
    {
            new NdiArtifact( "Sample executable (Linux)", "capisample", "capisample/build/linux/" ).shared( true ).required(),
            new NdiArtifact( "Dynamically-linked sample executable (Linux)", "capisample-dyn", "capisample/build/linux/" ).shared( true ).required(),
            new NdiArtifact( "Shared Library (Linux)", "libndicapi.so", "capisample/build/linux/" ).shared( true ).required()
    };
    
    private static final Artifact[] MAC_ARTIFACTS = new Artifact[]
    {
            new NdiArtifact( "Sample executable (Mac)", "capisample", "capisample/build/macosx/" ).shared( true ).required(),
            new NdiArtifact( "Dynamically-linked sample executable (Mac)", "capisample-dyn", "capisample/build/macosx/" ).shared( true ).required(),
            new NdiArtifact( "Shared Library (Mac)", "libndicapi.dylib", "capisample/build/macosx/" ).shared( true ).required()
    };
    
    private static final Artifact[] WINDOWS_ARTIFACTS = new Artifact[]
    {
            new NdiArtifact( "Sample executable", "sample.exe", "capisample/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "Dynamic linked library", "library.dll", "capisample/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "Static library", "library.lib", "capisample/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "Library Exports", "library.exp", "capisample/x64/Release/" ).shared( true ).required(),
    };
    
    private static final Artifact[] WINDOWS_ARDEMO_ARTIFACTS = new Artifact[]
    {
            new NdiArtifact( "AR Demo executable", "ardemo.exe", "capisample/ndigst/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "CAPItoGST dynamic library", "capitogst.dll", "capisample/ndigst/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "CAPItoGST static library", "capitogst.lib", "capisample/ndigst/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "AR Demo dynamic library", "library.dll", "capisample/ndigst/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "AR Demo static library", "library.lib", "capisample/ndigst/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "AR Demo exports", "library.exp", "capisample/ndigst/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "NDI Elements dynamic library", "ndielems.dll", "capisample/ndigst/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "NDI Elements static library", "ndielems.lib", "capisample/ndigst/x64/Release/" ).shared( true ).required(),
            new NdiArtifact( "NDI Elements exports", "ndielems.exp", "capisample/ndigst/x64/Release/" ).shared( true ).required()
    };
    
    private Job[] createCompileJobs()
    {
        // Common tasks
        NdiCheckoutTask taskCheckoutSrc = new NdiCheckoutTask( "Check out source repos", true )
            .addCheckoutOfRepository( "su_capisample", "${bamboo.SRC_DIR}" )
            .addCheckoutOfRepository( "ext_gstreamer-binaries", "external" );
        
        // Jobs
        Job jobLinux = new Job( "Build Linux", new BambooKey("CAPILNX") )
            .description("Builds Linux CAPI Sample")
            .requirements(
                new NdiRequirement( "os", MatchType.EQUALS, "ubuntu18.04"),
                new NdiRequirement("tools", MatchType.EQUALS, "x113")
            )
            .artifacts( LINUX_ARTIFACTS )
            .cleanWorkingDirectory( true )
            .tasks( taskCheckoutSrc, 
                    new NdiScriptTask( "Run make to build source", Interpreter.BINSH_OR_CMDEXE, "${bamboo.SRC_DIR}")
                    .inlineBody(
                            "echo 'Check openssl-devel version'\n" +
                            "ls -alh /lib/x86_64-linux-gnu/ | grep openssl\n" +
                            "echo 'Building CAPIsample ...'\n" +
                            "g++ --version\n" +
                            "make\n" ));
        
        Job jobMac = new Job( "Build Mac", new BambooKey("CAPIMAC") )
                .description("Builds Mac CAPI Sample")
                .requirements(
                    new NdiRequirement( "os", MatchType.EQUALS, "mac10.15"),
                    new NdiRequirement("tools", MatchType.EQUALS, "x113")
                )
                .artifacts( MAC_ARTIFACTS )
                .cleanWorkingDirectory( true )
                .tasks( taskCheckoutSrc, 
                        new NdiScriptTask( "Run make to build source", Interpreter.BINSH_OR_CMDEXE, "${bamboo.SRC_DIR}")
                        .inlineBody(
                                "echo 'Building CAPIsample ...'\n" +
                                "make\n" ),
                        new NdiScriptTask( "Compress build output", Interpreter.BINSH_OR_CMDEXE )
                        .inlineBody(
                                "echo 'Display dynamic library linking'\n" +
                                "otool -L ${bamboo.SRC_DIR}/${bamboo.BUILD_DIR}/macosx/capisample-dyn\n" +
                                "echo 'Compressing build output ...'\n" +
                                "rm -rf ${bamboo.SRC_DIR}/${bamboo.BUILD_DIR}/macosx/obj\n" +
                                "tar -cv ${bamboo.SRC_DIR}/${bamboo.BUILD_DIR}/macosx | gzip -9 > ${bamboo.ArchiveName}-mac.tar.gz\n"
                                ) );
        
        Job jobWindows = new Job( "Build Windows", new BambooKey("CAPIWIN") )
                .description("Builds Windows CAPI Sample")
                .requirements(
                    new NdiRequirement( "os", MatchType.EQUALS, "windows10"),
                    new NdiRequirement("tools", MatchType.EQUALS, "x113")
                )
                .artifacts( WINDOWS_ARTIFACTS )
                .artifacts( WINDOWS_ARDEMO_ARTIFACTS )
                .artifacts( new NdiArtifact( "Documentation", "**", "${bamboo.SRC_DIR}/docs/html" ) )
                .cleanWorkingDirectory( true )
                .tasks( taskCheckoutSrc, 
                        new NdiScriptTask( "Build shared library and sample application", Interpreter.BINSH_OR_CMDEXE, "${bamboo.SRC_DIR}")
                        .inlineBody( "msbuild.exe /p:Configuration=Release CAPIsample.sln\n" ),
                        new NdiScriptTask( "Build GStreamer demo", Interpreter.BINSH_OR_CMDEXE, "${bamboo.SRC_DIR}" )
                        .inlineBody( "msbuild.exe /p:Configuration=Release ./ndigst/ndigst.sln\n" )
                        .environmentVariables( "GSTREAMER_1_0_ROOT_X86_64=${bamboo.build.working.directory}\\external\\windows\\gstreamer\\1.0\\x86_64" ),
                        new NdiScriptTask( "Compress build output", Interpreter.BINSH_OR_CMDEXE )
                        .inlineBody(
                                "echo 'Display shared library linking using Cygwin ldd'\n" +
                                "ldd ${bamboo.SRC_DIR}/x64/Release/sample.exe ${bamboo.SRC_DIR}/x64/Release/library.dll\n" +
                                "echo 'Compressing build output ...'\n" +
                                "tar -cv ${bamboo.SRC_DIR}/x64/Release | gzip -9 > ${bamboo.ArchiveName}-win64.tar.gz\n" +
                                "tar --exclude='*.i*' -cv ${bamboo.SRC_DIR}/ndigst/x64/Release | gzip -9 > ${bamboo.ArchiveName}-ndigst-win64.tar.gz\n"
                                ),
                        new NdiScriptTask( "Generate Doxygen Documentation", Interpreter.BINSH_OR_CMDEXE, "${bamboo.SRC_DIR}")
                        .inlineBody( 
                                "echo 'Generating documentation using doxygen'\n" +
                                "doxygen --version\n" +
                                "which doxygen\n" +
                                "doxygen doxygen.conf\n" ) );
        return new Job[] { jobLinux, jobMac, jobWindows };
    }
    
    private Job createDistributionJob()
    {
        // Check out capi
        NdiCheckoutTask taskCheckoutSrc = new NdiCheckoutTask( "Check out source repos", true )
                .addCheckoutOfRepository( "su_capisample", "sw/capisample" );
        
        // Download Linux artifacts
        DownloadItem[] linuxDownloads = new DownloadItem[ LINUX_ARTIFACTS.length ];
        for( int i = 0; i < linuxDownloads.length; i++ )
        {
            linuxDownloads[i] = new DownloadItem().artifact( LINUX_ARTIFACTS[i].getName() ).path( "sw/capisample/bin/linux/" );
        }
        ArtifactDownloaderTask taskDownloadLinuxArtifacts = new ArtifactDownloaderTask().artifacts( linuxDownloads );
        
        // Download Mac artifacts
        DownloadItem[] macDownloads = new DownloadItem[ MAC_ARTIFACTS.length ];
        for( int i = 0; i < macDownloads.length; i++ )
        {
            macDownloads[i] = new DownloadItem().artifact( MAC_ARTIFACTS[i].getName() ).path( "sw/capisample/bin/macosx/" );
        }
        ArtifactDownloaderTask taskDownloadMacArtifacts = new ArtifactDownloaderTask().artifacts( macDownloads );
        
        // Download Linux artifacts
        DownloadItem[] windowsDownloads = new DownloadItem[ WINDOWS_ARTIFACTS.length ];
        for( int i = 0; i < windowsDownloads.length; i++ )
        {
            windowsDownloads[i] = new DownloadItem().artifact( WINDOWS_ARTIFACTS[i].getName() ).path( "sw/capisample/bin/win64/" );
        }
        ArtifactDownloaderTask taskDownloadWindowsArtifacts = new ArtifactDownloaderTask().artifacts( windowsDownloads );
        
        // Download Linux artifacts
        DownloadItem[] windowsARDemoDownloads = new DownloadItem[ WINDOWS_ARDEMO_ARTIFACTS.length ];
        for( int i = 0; i < windowsARDemoDownloads.length; i++ )
        {
            windowsARDemoDownloads[i] = new DownloadItem().artifact( WINDOWS_ARDEMO_ARTIFACTS[i].getName() ).path( "sw/capisample/ndigst/bin/" );
        }
        ArtifactDownloaderTask taskDownloadWindowsARDemoArtifacts = new ArtifactDownloaderTask().artifacts( windowsARDemoDownloads );
        
        // Copy to a directory with a nicer name "CombinedAPIsample" for distribution
        NdiScriptTask taskCopyDistribution = new NdiScriptTask( "Collects CAPI Sample distribution", Interpreter.BINSH_OR_CMDEXE );
        taskCopyDistribution.inlineBody( "mkdir CombinedAPIsample\n" +
                "cp -r sw/capisample/* CombinedAPIsample\n" +
                "cd CombinedAPIsample && ls -alhR\n");
        
        // Get the version from running the sample, and then create a tarball
        NdiScriptTask taskArchiveOutput = new NdiScriptTask( "Archives the output", Interpreter.BINSH_OR_CMDEXE );
        taskArchiveOutput.inlineBody(
                "#!/bin/bash\n" +
                "# get the version of CAPI sample\n" +
                "./sw/capisample/bin/linux/capisample > help.txt\n" +
                "capi_version=`grep \"CAPIsample Ver \" help.txt | sed -e 's/CAPIsample Ver //g'`\n" +
                "rm help.txt\n" + 
                "# create a tarball\n" +
                "tar -cv CombinedAPIsample | gzip -9 > 'Combined API Sample C++ v'$capi_version'.tar.gz'\n");
        
        // Job to create and publish the artifact
        Job job = new Job( "Create CAPI Sample distribution", new BambooKey("CAPIDISTRO") )
                .description("Builds the CAPI Sample distribution tarball")
                .requirements(
                    new NdiRequirement( "os", MatchType.EQUALS, "ubuntu18.04" ),
                    new NdiRequirement( "tools", MatchType.EQUALS, "x113" )
                )
                .artifacts( new NdiArtifact( "CAPI Sample tarball", "Combined API Sample C++ v*", "" ) )
                .cleanWorkingDirectory( true )
                .tasks( taskCheckoutSrc,
                        taskDownloadLinuxArtifacts, taskDownloadMacArtifacts, taskDownloadWindowsArtifacts, taskDownloadWindowsARDemoArtifacts,
                        taskCopyDistribution, taskArchiveOutput );
        
        return job;
    }
    
    private Stage createBuildStage()
    {
        return new Stage( "Multiplatform").jobs( createCompileJobs() );
    }
    
    private Stage createDistributionStage()
    {
        return new Stage( "Distribution" ).jobs( createDistributionJob() );
    }

    public Plan plan()
    {
        // Create the plan
        Project project = new Project().key( new BambooKey("SU") );
        final Plan plan =
                new Plan( project, "Spec build of CAPI Sample", new BambooKey("SPECCAPI") )
                .description("Sample application demonstrating the Combined API (CAPI)" )
                .pluginConfigurations( new ConcurrentBuilds() )
                .triggers( new BitbucketServerTrigger().enabled( true ) )
                .notifications(
                        new Notification()
                        .type( new PlanCompletedNotification() )
                        .recipients( new AnyNotificationRecipient( new AtlassianModule("com.atlassian.bamboo.plugins.bamboo-stash-plugin:recipient.stash") ) ),
                        new Notification()
                        .type( new PlanFailedNotification() )
                        .recipients( new CommittersRecipient(), new WatchersRecipient() )
                        )
                .planBranchManagement(
                        new PlanBranchManagement()
                        .createForVcsBranch()
                        .delete( new BranchCleanup().whenRemovedFromRepositoryAfterDays(1).whenInactiveInRepositoryAfterDays(7))
                        .triggerBuildsManually()
                        .notificationLikeParentPlan()
                        .branchIntegration(new BranchIntegration()
                                .integrationBranch(new PlanBranchIdentifier(new BambooKey("SPECCAPI")))
                                .gatekeeper(true))
                        );

        // STAGES
        plan.stages( createBuildStage(), createDistributionStage() );

        for( RepoInfoEntry entry : secondaryRepoInfo.getRepoInfoEntries() )
        {
            plan.linkedRepositories( entry.linkedRepoName );
            plan.variables( new Variable( "branch_" + entry.linkedRepoName, entry.label ) );
            plan.repositoryBranches( new VcsRepositoryBranch( entry.linkedRepoName, "${bamboo.branch_" + entry.linkedRepoName + "}" ) );
        }

        plan.variables(
                new Variable( "ArchiveName", "capisample" ),
                new Variable( "BUILD_DIR", "build" ),
                new Variable( "OUT_DIR", "build" ),
                new Variable( "SRC_DIR", "capisample" ),
                new Variable( "branch_gstreamer-binaries", "master" )
                )
        .forceStopHungBuilds();

        return plan;
    }
    
    /**
     * Configures user and group permissions for the plan
     *
     * IMPORTANT:  If possible, all permissions should be configured at the project level and not
     *             at this plan level.  Only add permissions here when they have to be different
     *             from the plan permissions.
     *
     * @return plan permissions
     */
    public PlanPermissions planPermission()
    {
        final PlanPermissions planPermission =
            new PlanPermissions(
             new PlanIdentifier("SU", "SPECCAPI") )
            .permissions(
                new Permissions()
                    .groupPermissions("CA_BitbucketBamboo_RnD_Users", PermissionType.VIEW, PermissionType.EDIT, PermissionType.BUILD, PermissionType.CLONE)
            );

        return planPermission;
    }

    /**
     * This is required by the Bamboo framework.
     * @param argv cmd-line args
     */
    public static void main(String... argv)
    {
        BambooServer bambooServer = new BambooServer("https://bamboo.ndigital.com");
        final CAPIPlanSpec planSpec = new CAPIPlanSpec();

        final Plan plan = planSpec.plan();
        bambooServer.publish(plan);

        final PlanPermissions planPermission = planSpec.planPermission();
        bambooServer.publish(planPermission);
    }
}



