/*
 * Copyright 2022 by Northern Digital Inc.
 * All Rights Reserved
 */
package ndi_bamboo_specs.wrappers;

import com.atlassian.bamboo.specs.api.builders.requirement.Requirement;

/**
 * Convenience class providing a compact syntax for specifying environment requirements.
 *
 */
public class NdiRequirement extends Requirement
{
    public NdiRequirement(String key, MatchType match, String value)
    {
        super(key);
        
        this.matchType( match ).matchValue( value );
    }
}
