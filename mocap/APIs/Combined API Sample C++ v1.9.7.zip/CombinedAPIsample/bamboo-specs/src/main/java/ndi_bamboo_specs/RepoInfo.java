/*
 * Copyright 2022 by Northern Digital Inc.
 * All Rights Reserved
 */
package ndi_bamboo_specs;

import java.util.Vector;
import java.io.BufferedReader;
import java.io.FileReader;

public class RepoInfo
{
    private Vector<RepoInfoEntry> repoInfoEntries = new Vector<RepoInfoEntry>();
    
    RepoInfo( String inputFilename )
    {
        try
        {
            // Clone repositories based on information specified in a csv (comma-separated values) file
            // A csv file is used so both the developer's clone script and Bamboo can get cloning 
            // information from the same location.
            //
            // CSV Format:  clone-URL, branch/tag-to-checkout, project-relative-local-path-to-clone-to, special-clone-options*
            //   *The special options are ignored by Bamboo
            //   Examples
            //       ssh://git@bitbucket.ndigital.com:7999/ext/catch.git, v2.1.0, open_source/catch, --depth 1
            //       ssh://git@bitbucket.ndigital.com:7999/ndi/ble_easy.git, master, common/ble_easy, 
            //
            // Notes:
            // - Blank fields are represented by a comma and space (i.e. no special-clone-options would be ", ")
            // - Don't put any comments or empty lines in the csv file.
            // - File must use Unix-style line endings!  (line-feeds, not carriage-return + line-feeds).
            BufferedReader br = new BufferedReader(new FileReader(inputFilename));
            
            String line = "";
            while((line = br.readLine()) != null)
            {
                // Split the string based on commas and trim spaces from start of strings
                //      fields[0] = url
                //      fields[1] = label
                //      fields[2] = localPath
                //      fields[3] = options
                String[] fields = line.split(",");
                for(int i = 0; i < fields.length; i++)
                {
                    fields[i] = fields[i].trim();
                }
                
                // Extract the repo name from the URL (text after the last '/' but before the trailing ".git")
                String repoName = fields[0].substring(fields[0].lastIndexOf("/") + 1, fields[0].length() - 4);
                // Add the Bitbucket project key as a prefix (text between the second-last and last '/')
                String urlPath = fields[0].substring(0, fields[0].lastIndexOf("/"));    // Get rid of the repo name and last '/'
                String linkedRepoName = urlPath.substring(urlPath.lastIndexOf("/") + 1) + "_" + repoName;
                
                String p_url = fields.length > 0 ? fields[0] : "";
                String p_label = fields.length > 1 ? fields[1] : "";
                String p_localPath = fields.length > 2 ? fields[2] : "";
                String p_options = fields.length > 3 ? fields[3] : "";
                repoInfoEntries.addElement(new RepoInfoEntry(p_url, p_label, p_localPath, p_options, repoName, linkedRepoName));
                
                // Uncomment these lines to debug issues with the input file formatting
                //RepoInfoEntry entry = repoInfoEntries.elementAt(repoInfoEntries.size()-1);
                //System.out.println("Entry " + repoInfoEntries.size() + " = " + entry.url + " | " + entry.label + " | " + 
                //        entry.localPath + " | " + entry.options + " | " + entry.linkedRepoName);
            }
            
            br.close();
            
        }
        catch (Exception e)
        {
            System.out.println("Error loading data from '" + inputFilename + "' from: " + System.getProperty("user.dir") + ": " + e.getMessage());
        }
    }
    
    public Vector<RepoInfoEntry> getRepoInfoEntries()
    {
        return repoInfoEntries;
    }    
}
